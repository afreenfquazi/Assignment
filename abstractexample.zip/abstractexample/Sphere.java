package abstractexample;

public class Sphere extends Shape3D{
	static final double pi=3.14;
	double r=3.0;
	@Override
	public void volume() {
	double vol =(4/3)*pi*r*r*r;
	System.out.println("Volume of a sphere is "+vol);
		
	}

	@Override
	public void surfaceArea() {
		double area = 4*pi*r;
		System.out.println("Surface area of a sphere "+area);
	}

}
