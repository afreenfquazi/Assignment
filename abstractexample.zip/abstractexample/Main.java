package abstractexample;

public class Main {
	public static void main(String[] args) {
		Cylinder c = new Cylinder();
		c.surfaceArea();
		c.volume();
		Sphere s = new Sphere();
		s.surfaceArea();
		s.volume();
		Cube cb = new Cube();
		cb.surfaceArea();
		cb.volume();
	}
}
