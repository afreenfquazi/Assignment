package abstractexample;

public class Cube extends Shape3D {
	private int a=3;
	

	@Override
	public void volume() {
		int vol = a * a * a;
	System.out.println("Volume of cube "+vol);

	}

	@Override
	public  void surfaceArea() {
		double area = 6*a*a;
		System.out.println("surface area of cube "+area);
		
	}

}
