package abstractexample;

public abstract  class Shape3D {
	public abstract  void volume();
	public abstract  void surfaceArea();


}
