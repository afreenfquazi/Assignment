package abstractexample;

public class Cylinder extends Shape3D {
	static final double pi = 3.14;
	double r=3.5,h=4.9;
	@Override
	public void surfaceArea() {
		double area = (2 * pi * r * h) + (2 * pi * r * r);
		System.out.println("surface area of cylinder "+area);

	}

	@Override
	public void volume() {
	double vol = pi*r*r*h;
	System.out.println("Volume of a cylindre is "+vol);
	}

}
