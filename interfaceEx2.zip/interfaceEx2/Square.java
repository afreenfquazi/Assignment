package interfaceEx2;

public class Square implements Drawable,Fillable {

	@Override
	public void fillingColor() {
	
		
	}

	@Override
	public void size() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void drawingColor() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void thickness() {
		// TODO Auto-generated method stub
		
	}

}
