package interfaceEx2;

public interface Drawable {
	public void drawingColor();
	public void thickness();

}
