package interfaceEx2;

public interface Fillable {
	public void fillingColor();
	public void size();
}
